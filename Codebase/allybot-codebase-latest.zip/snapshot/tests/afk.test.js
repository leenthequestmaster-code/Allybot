import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import pino from 'pino'
import Database from 'better-sqlite3'
import { ApplicationFramework } from '../dist/framework/application.js'
import { createAfkPlugin } from '../dist/framework/plugins/afk.js'
import { menuPlugin } from '../dist/framework/plugins/menu.js'
import {
  AfkService,
  MAX_AFK_REASON_LENGTH,
} from '../dist/services/afk-service.js'
import { GroupConfigurationService } from '../dist/services/group-configuration-service.js'

const logger = pino({ level: 'silent' })
const config = { commandPrefix: '!', defaultCooldownMs: 0 }

class FakeCore {
  isConnected = false
  userJid = 'bot@s.whatsapp.net'
  sent = []
  messages = new Set()
  groupParticipantListeners = new Set()
  connections = new Set()

  onMessage(listener) { this.messages.add(listener); return () => this.messages.delete(listener) }
  onGroupParticipantUpdate(listener) { this.groupParticipantListeners.add(listener); return () => this.groupParticipantListeners.delete(listener) }
  onConnectionState(listener) { this.connections.add(listener); return () => this.connections.delete(listener) }
  async sendText(remoteJid, text, options) { this.sent.push({ remoteJid, text, options }) }
  async start() {
    this.isConnected = true
    await Promise.all([...this.connections].map((listener) => listener({ status: 'connected', at: Date.now() })))
  }
  async close() {
    this.isConnected = false
    await Promise.all([...this.connections].map((listener) => listener({ status: 'idle', at: Date.now() })))
  }
  async emitMessage(message) {
    await Promise.all([...this.messages].map((listener) => listener(message)))
  }
}

function message(id, senderJid, remoteJid, text, mentionedJids = [], metadata = {}) {
  return {
    id,
    senderJid,
    remoteJid,
    text,
    mentionedJids,
    timestamp: Date.now(),
    fromMe: false,
    ...metadata,
  }
}

test('AFK plugin persists state, forwards every mention privately, and auto-unsets on return', async (context) => {
  const directory = mkdtempSync(join(tmpdir(), 'allybot-afk-'))
  context.after(() => rmSync(directory, { recursive: true, force: true }))

  const core = new FakeCore()
  const app = new ApplicationFramework(config, logger, core, {
    prefixResolver: (message, services, fallback) => message.remoteJid.endsWith('@g.us')
      ? services.get('group-configuration').resolvePrefix(message.remoteJid, fallback)
      : fallback,
  })
  const afk = new AfkService(join(directory, 'core.sqlite'), logger)
  const groupConfiguration = new GroupConfigurationService(join(directory, 'core.sqlite'), logger)
  app.registerService(afk)
  app.registerService(groupConfiguration)
  app.registerPlugin(menuPlugin)
  app.registerPlugin(createAfkPlugin(core))
  await app.start()

  const groupJid = 'roleplay@g.us'
  const aliceJid = 'alice@s.whatsapp.net'
  const bobJid = 'bob@s.whatsapp.net'
  groupConfiguration.setPrefix(groupJid, '##', 'admin@s.whatsapp.net')

  await core.emitMessage(message('set-afk', aliceJid, groupJid, '!afk makan malam'))
  assert.match(core.sent[0].text, /sekarang AFK/)
  assert.equal(afk.getActive(aliceJid)?.reason, 'makan malam')

  await core.emitMessage(message('mention-1', bobJid, groupJid, '@alice kamu di mana?', [aliceJid], {
    groupName: 'Kansei',
    quotedText: 'Kamu ada di mana?'
  }))
  assert.equal(core.sent.length, 3)
  assert.equal(core.sent[1].remoteJid, groupJid)
  assert.match(core.sent[1].text, /Mention kamu sudah diteruskan/)
  assert.equal(core.sent[2].remoteJid, aliceJid)
  assert.match(core.sent[2].text, /menyebutmu ketika kamu AFK/)
  assert.match(core.sent[2].text, /Grup.*Kansei/)
  // Privacy: mention content is no longer stored or echoed back.
  assert.doesNotMatch(core.sent[2].text, /Pesan/)
  assert.doesNotMatch(core.sent[2].text, /Reply/)
  assert.doesNotMatch(core.sent[2].text, /@alice kamu di mana/)
  assert.doesNotMatch(core.sent[2].text, /Kamu ada di mana/)
  assert.equal(afk.getMentions(aliceJid)[0]?.groupName, 'Kansei')
  assert.equal(afk.getMentions(aliceJid)[0]?.messageText, undefined)
  assert.equal(afk.getMentions(aliceJid)[0]?.quotedText, undefined)
  assert.equal(afk.getActive(aliceJid)?.searchCount, 1)

  await core.emitMessage(message('mention-2', bobJid, groupJid, '@alice tolong jawab', [aliceJid]))
  assert.equal(core.sent.length, 5)
  assert.deepEqual(core.sent.at(-1)?.options?.mentions, [bobJid])
  assert.equal(afk.getActive(aliceJid)?.searchCount, 2)

  await core.emitMessage(message('reply-only', bobJid, groupJid, 'aku balas pesanmu', [], {
    groupName: 'Kansei',
    quotedText: 'alice, nanti kabari ya',
    quotedSenderJid: aliceJid,
  }))
  assert.equal(core.sent.length, 7)
  assert.equal(afk.getActive(aliceJid)?.searchCount, 3)
  assert.deepEqual(core.sent.at(-1)?.options?.mentions, [bobJid])
  assert.doesNotMatch(core.sent.at(-1)?.text ?? '', /aku balas pesanmu/)

  await core.emitMessage(message('private-status', aliceJid, groupJid, '!afk status'))
  assert.equal(core.sent.at(-1)?.remoteJid, aliceJid)
  assert.match(core.sent.at(-1)?.text ?? '', /makan malam/)

  await core.emitMessage(message('return', aliceJid, groupJid, 'aku kembali'))
  assert.equal(afk.getActive(aliceJid), undefined)
  assert.equal(core.sent.at(-1)?.remoteJid, groupJid)
  assert.match(core.sent.at(-1)?.text ?? '', /Selamat datang kembali/)
  assert.equal(afk.totalRecorded(), 1)
  assert.equal(afk.listLeaderboard()[0]?.userJid, aliceJid)

  await app.stop()
})

test('AFK hardening bounds retention and context and throttles presence writes', (context) => {
  const directory = mkdtempSync(join(tmpdir(), 'allybot-afk-hardening-'))
  context.after(() => rmSync(directory, { recursive: true, force: true }))

  const databasePath = join(directory, 'core.sqlite')
  const afk = new AfkService(databasePath, logger, {
    mentionRetention: 2,
    mentionRetentionMs: 1_000_000,
    presenceWriteIntervalMs: 60_000,
  })
  afk.initialize({})
  const aliceJid = 'alice@s.whatsapp.net'
  const bobJid = 'bob@s.whatsapp.net'
  const groupJid = 'roleplay@g.us'
  const base = Date.now()

  const started = afk.start(aliceJid, 'x'.repeat(MAX_AFK_REASON_LENGTH + 50), base)
  assert.equal(started.reason.length, MAX_AFK_REASON_LENGTH)

  afk.touchPresence(bobJid, base)
  afk.touchPresence(bobJid, base + 59_999)
  const connection = new Database(join(directory, 'allybot-afk.sqlite'))
  assert.equal(connection.prepare('SELECT last_seen_at FROM afk_presence WHERE user_jid = ?').get(bobJid).last_seen_at, base)
  afk.touchPresence(bobJid, base + 60_000)
  assert.equal(connection.prepare('SELECT last_seen_at FROM afk_presence WHERE user_jid = ?').get(bobJid).last_seen_at, base + 60_000)

  const first = afk.recordMentionWithResult(aliceJid, bobJid, groupJid, base + 1, 'Room', 'first secret message content')
  const second = afk.recordMentionWithResult(aliceJid, bobJid, groupJid, base + 2, 'Room', 'second secret message content')
  const third = afk.recordMentionWithResult(
    aliceJid,
    bobJid,
    groupJid,
    base + 3,
    'R'.repeat(500),
  )
  // Privacy regression: message/quoted content must never be persisted.
  assert.equal(first?.messageText, undefined)
  assert.equal(first?.quotedText, undefined)
  assert.equal(second?.messageText, undefined)
  assert.equal(third?.groupName?.length, 200)
  assert.equal(afk.getMentions(aliceJid).length, 2)
  assert.equal(afk.getMentions(aliceJid).every((mention) => mention.messageText === undefined && mention.quotedText === undefined), true)
  const connection2 = new Database(join(directory, 'allybot-afk.sqlite'))
  const stored = connection2.prepare('SELECT message_text, quoted_text FROM afk_mentions').all()
  assert.equal(stored.every((row) => row.message_text === null && row.quoted_text === null), true)
  connection2.close()

  connection.close()
  afk.shutdown({})
})

test('AFK migration converts legacy mention timestamps from seconds to milliseconds', (context) => {
  const directory = mkdtempSync(join(tmpdir(), 'allybot-afk-migration-'))
  context.after(() => rmSync(directory, { recursive: true, force: true }))

  const databasePath = join(directory, 'allybot-afk.sqlite')
  const legacy = new Database(databasePath)
  legacy.exec(`
    CREATE TABLE afk_mentions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      afk_user_jid TEXT NOT NULL,
      seeker_jid TEXT NOT NULL,
      chat_jid TEXT NOT NULL,
      mentioned_at INTEGER NOT NULL
    );
  `)
  legacy.prepare(
    'INSERT INTO afk_mentions (afk_user_jid, seeker_jid, chat_jid, mentioned_at) VALUES (?, ?, ?, ?)',
  ).run('alice@s.whatsapp.net', 'bob@s.whatsapp.net', 'roleplay@g.us', 1_700_000_000)
  legacy.close()

  const afk = new AfkService(join(directory, 'core.sqlite'), logger, {
    mentionRetentionMs: 100 * 365 * 24 * 60 * 60 * 1_000,
  })
  afk.initialize({})
  assert.equal(afk.getMentions('alice@s.whatsapp.net')[0]?.mentionedAt, 1_700_000_000_000)
  afk.shutdown({})
})

test('AFK mention storage never leaks legacy plaintext rows through the read path', (context) => {
  const directory = mkdtempSync(join(tmpdir(), 'allybot-afk-legacy-'))
  context.after(() => rmSync(directory, { recursive: true, force: true }))

  const databasePath = join(directory, 'allybot-afk.sqlite')
  const legacy = new Database(databasePath)
  legacy.exec(`
    CREATE TABLE afk_mentions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      afk_user_jid TEXT NOT NULL,
      seeker_jid TEXT NOT NULL,
      chat_jid TEXT NOT NULL,
      group_name TEXT NOT NULL DEFAULT '',
      message_text TEXT,
      quoted_text TEXT,
      mentioned_at INTEGER NOT NULL
    );
  `)
  // Simulate a pre-fix production row that still holds plaintext content.
  legacy.prepare(
    'INSERT INTO afk_mentions (afk_user_jid, seeker_jid, chat_jid, group_name, message_text, quoted_text, mentioned_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
  ).run('alice@s.whatsapp.net', 'bob@s.whatsapp.net', 'roleplay@g.us', 'Kansei', 'legacy plaintext secret', 'legacy quoted secret', Date.now())
  legacy.close()

  const afk = new AfkService(join(directory, 'core.sqlite'), logger, {
    mentionRetentionMs: 100 * 365 * 24 * 60 * 60 * 1_000,
  })
  afk.initialize({})

  const mentions = afk.getMentions('alice@s.whatsapp.net')
  assert.equal(mentions.length, 1)
  const serialized = JSON.stringify(mentions)
  assert.equal(serialized.includes('legacy plaintext secret'), false)
  assert.equal(serialized.includes('legacy quoted secret'), false)
  assert.equal(mentions[0]?.groupName, 'Kansei')
  assert.equal(mentions[0]?.messageText, undefined)
  assert.equal(mentions[0]?.quotedText, undefined)
  afk.shutdown({})
})
